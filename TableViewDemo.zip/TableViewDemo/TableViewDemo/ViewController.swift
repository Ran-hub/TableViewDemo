//
//  ViewController.swift
//  TableViewDemo
//
//  Created by Pavan Kumar N on 14/06/18.
//  Copyright © 2018 Pavan Kumar N. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
        @IBOutlet weak var myTableView: UITableView!
    
    var dataArray = NSMutableArray()
    var myArray = NSArray()

    override func viewDidLoad() {
        super.viewDidLoad()
    

        getDataFromServer()
        // Do any additional setup after loading the view, typically from a nib.
    }
    func getDataFromServer(){
        
        let url = URL(string: "https://jsonplaceholder.typicode.com/posts")!
        let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
            guard let unwrappedData = data else { return }
            do {
                let str = try JSONSerialization.jsonObject(with: unwrappedData, options: .allowFragments) as! NSDictionary
                 print(str)
                
                self.myArray = str["results"] as! NSArray
                self.myTableView.reloadData()
                
                print(self.myArray)
            } catch {
                print("json error: \(error)")
            }
        }
        task.resume()
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return dataArray.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
      {
        return 80
     }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = myTableView.dequeueReusableCell(withIdentifier: "customCell", for: indexPath) as! CustomTableViewCell
        let dict = dataArray.object(at: indexPath.row) as! NSDictionary
        cell.firstLabel.text = dict["userId"] as? String
        cell.secondLabel.text = dict["id"] as? String
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let firstVC = self.storyboard?.instantiateViewController(withIdentifier: "push") as! FirstViewController
        firstVC.datDict = dataArray.object(at: indexPath.row) as! NSDictionary
        self.navigationController?.pushViewController(firstVC, animated: true)
    }


}

