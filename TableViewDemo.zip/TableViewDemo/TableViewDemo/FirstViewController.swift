//
//  FirstViewController.swift
//  TableViewDemo
//
//  Created by Pavan Kumar N on 14/06/18.
//  Copyright © 2018 Pavan Kumar N. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {
    var datDict =  NSDictionary()

    @IBOutlet weak var addressLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var mobileLabel: UILabel!
    @IBOutlet weak var companyLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var dataLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        nameLabel.text = datDict["name"] as? String
        mobileLabel.text = datDict["mobile"] as? String
        companyLabel.text = datDict["company"] as? String
        addressLabel.text = datDict["address"] as? String
        emailLabel.text = datDict["acb"] as? String
        dataLabel.text = datDict["cdjd"] as? String

    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
